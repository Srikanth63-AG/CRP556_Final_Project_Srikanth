import arcpy
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os

arcpy.env.overwriteOutput = True

# --------------------------------------------------------------
# OVERWRITE CONTROLS
# --------------------------------------------------------------
OVERWRITE_RASTERS = True
OVERWRITE_GRID = True
OVERWRITE_PLOTS = True

# --------------------------------------------------------------
# INPUT ROOT
# --------------------------------------------------------------
ROOT = r"C:\Users\sri63\OneDrive - Iowa State University\Desktop\GIS_final_project\Resampled_Veg_Indices"

OUT = os.path.join(os.path.dirname(ROOT), "Temporal_Analysis_Output")
os.makedirs(OUT, exist_ok=True)

# --------------------------------------------------------------
# STEP 1 — DISCOVER TIMEPOINT FOLDERS
# --------------------------------------------------------------
tp_folders = sorted([
    os.path.join(ROOT, d)
    for d in os.listdir(ROOT)
    if os.path.isdir(os.path.join(ROOT, d)) and d.startswith("TP")
])

if len(tp_folders) < 2:
    raise RuntimeError("At least two TP folders are required.")

# --------------------------------------------------------------
# STEP 2 — FIND NDVI & NDRI FILES
# --------------------------------------------------------------
ndvi, ndri = {}, {}

for tp_path in tp_folders:
    tp = os.path.basename(tp_path).split("_")[0]
    for f in os.listdir(tp_path):
        if f.endswith("_NDVI.tif"):
            ndvi[tp] = os.path.join(tp_path, f)
        elif f.endswith("_NDRI.tif"):
            ndri[tp] = os.path.join(tp_path, f)

for tp in ["TP1", "TP2", "TP3"]:
    if tp not in ndvi or tp not in ndri:
        raise RuntimeError(f"Missing NDVI or NDRI for {tp}")

# --------------------------------------------------------------
# STEP 3 — REFERENCE CELL SIZE (TP1)
# --------------------------------------------------------------
TP1_cell = arcpy.Describe(ndvi["TP1"]).meanCellWidth

# --------------------------------------------------------------
# STEP 4 — RESAMPLE
# --------------------------------------------------------------
def resample(in_ras, name):
    out = os.path.join(OUT, f"{name}_RES.tif")
    if os.path.exists(out) and not OVERWRITE_RASTERS:
        print(f"↩ Using existing raster: {out}")
        return out
    arcpy.management.Resample(in_ras, out, TP1_cell, "BILINEAR")
    return out

ndvi_res = {"TP1": ndvi["TP1"]}
ndri_res = {"TP1": ndri["TP1"]}

for tp in ["TP2", "TP3"]:
    ndvi_res[tp] = resample(ndvi[tp], f"NDVI_{tp}")
    ndri_res[tp] = resample(ndri[tp], f"NDRI_{tp}")

# --------------------------------------------------------------
# STEP 5 — GRID POLYGON
# --------------------------------------------------------------
GRID = os.path.join(OUT, "TP1_grid.shp")
arcpy.CheckOutExtension("3D")

if OVERWRITE_GRID and os.path.exists(GRID):
    arcpy.management.Delete(GRID)

if not os.path.exists(GRID):
    arcpy.ddd.RasterDomain(ndvi["TP1"], GRID, "POLYGON")

# --------------------------------------------------------------
# STEP 6 — CLIP
# --------------------------------------------------------------
def clip(in_ras, name):
    out = os.path.join(OUT, f"{name}_CLIP.tif")
    if os.path.exists(out) and not OVERWRITE_RASTERS:
        print(f"↩ Using existing raster: {out}")
        return out
    arcpy.management.Clip(
        in_raster=in_ras,
        rectangle="#",
        out_raster=out,
        in_template_dataset=GRID,
        nodata_value="0",
        clipping_geometry="ClippingGeometry",
        maintain_clipping_extent="MAINTAIN_EXTENT"
    )
    return out

ndvi_clip, ndri_clip = {}, {}
for tp in ["TP1", "TP2", "TP3"]:
    ndvi_clip[tp] = clip(ndvi_res[tp], f"NDVI_{tp}")
    ndri_clip[tp] = clip(ndri_res[tp], f"NDRI_{tp}")

# --------------------------------------------------------------
# STEP 7 — ARRAY CONVERSION
# --------------------------------------------------------------
def to_array(path):
    return arcpy.RasterToNumPyArray(path, nodata_to_value=np.nan).astype("float64")

# --------------------------------------------------------------
# STEP 8 — PLOTTING
# --------------------------------------------------------------
PLOT_DIR = os.path.join(OUT, "plots")
os.makedirs(PLOT_DIR, exist_ok=True)

def heatmap(changes, titles, main_title, out_png):
    if os.path.exists(out_png) and not OVERWRITE_PLOTS:
        print(f"↩ Skipping existing plot: {out_png}")
        return

    fig = plt.figure(figsize=(22, 8))
    gs = gridspec.GridSpec(1, 4, width_ratios=[1, 1, 1, 0.06], wspace=0.20)

    vmin = np.nanmin([np.nanmin(a) for a in changes])
    vmax = np.nanmax([np.nanmax(a) for a in changes])

    for i in range(3):
        ax = fig.add_subplot(gs[i])
        im = ax.imshow(changes[i], cmap="RdYlGn", vmin=vmin, vmax=vmax)
        ax.set_title(titles[i], fontsize=16)
        ax.axis("off")

    cax = fig.add_subplot(gs[3])
    fig.colorbar(im, cax=cax).set_label("Δ Index Value")

    fig.suptitle(main_title, fontsize=20)
    plt.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.close()

def cdf_plot(vals, labels, title, out_png):
    if os.path.exists(out_png) and not OVERWRITE_PLOTS:
        print(f"↩ Skipping existing plot: {out_png}")
        return

    plt.figure(figsize=(10, 8))
    for v, lab in zip(vals, labels):
        v = v[~np.isnan(v)]
        s = np.sort(v)
        p = np.linspace(0, 1, len(s))
        plt.plot(s, p, label=lab, linewidth=2)

    plt.xlabel("Index Value")
    plt.ylabel("Cumulative Probability")
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.savefig(out_png, dpi=300)
    plt.close()

# --------------------------------------------------------------
# STEP 9 — PROCESS
# --------------------------------------------------------------
metrics = {"NDVI": ndvi_clip, "NDRI": ndri_clip}

for metric, data in metrics.items():
    A1, A2, A3 = map(to_array, [data["TP1"], data["TP2"], data["TP3"]])

    heatmap(
        [A2 - A1, A3 - A2, A3 - A1],
        ["TP2 - TP1", "TP3 - TP2", "TP3 - TP1"],
        f"{metric} Temporal Change",
        os.path.join(PLOT_DIR, f"{metric}_heatmap.png")
    )

    cdf_plot(
        [A1.flatten(), A2.flatten(), A3.flatten()],
        ["TP1", "TP2", "TP3"],
        f"{metric} CDF",
        os.path.join(PLOT_DIR, f"{metric}_CDF.png")
    )

print("\n🎉 Temporal analysis complete!")
print("Plots saved to:", PLOT_DIR)
